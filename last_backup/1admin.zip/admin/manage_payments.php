<?php
session_start();
include '../db.php'; // Make sure this path is correct to your db.php file

// Set default timezone to Asia/Dhaka (fallback)
date_default_timezone_set('Asia/Dhaka');

// Ensure only admin can access this page
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// Retrieve user ID from session
$user_id = $_SESSION['user_id'];

// Get username from the database
$stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
$username = $user ? $user['username'] : '';

// Include the admin header
include 'header.php'; // Make sure this path is correct

// Connect to the database
$conn = new mysqli('localhost', 'domhoste_test', 'domhoste_test', 'domhoste_test');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all payments with status 'pending', 'approved', or 'rejected' along with the username and created_at
$sql = "SELECT mp.id, mp.user_id, mp.amount, mp.transaction_id, mp.payment_method, mp.status, mp.created_at, u.username
        FROM manual_payments mp
        JOIN users u ON mp.user_id = u.id"; // Assuming users table has 'id' and 'username' columns

$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payments List</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            flex: 1; /* Makes the container take available space */
        }
        h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        table th, table td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        table th {
            background-color: #007bff;
            color: white;
        }
        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .actions a {
            text-decoration: none;
            color: white;
            padding: 5px 10px;
            border-radius: 5px;
            margin: 0 5px;
            font-weight: bold;
        }
        .approve {
            background-color: #28a745;
        }
        .reject {
            background-color: #dc3545;
        }
        .actions a:hover {
            opacity: 0.8;
        }
        .no-payments {
            text-align: center;
            color: #666;
        }
        footer {
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 10px;
            margin-top: auto;  /* Pushes footer to the bottom */
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Payments List</h2>

    <?php
    if ($result->num_rows > 0) {
        echo "<table>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Amount</th>
                    <th>Transaction ID</th>
                    <th>Payment Method</th>
                    <th>Status</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>";

        // Display each payment with the username and created_at
        while($row = $result->fetch_assoc()) {
            // Format the created_at date (optional)
            $created_at = date('Y-m-d H:i:s', strtotime($row['created_at']));
            
            echo "<tr>
                    <td>" . $row['id'] . "</td>
                    <td>" . $row['username'] . "</td>
                    <td>" . $row['amount'] . "</td>
                    <td>" . $row['transaction_id'] . "</td>
                    <td>" . $row['payment_method'] . "</td>
                    <td>" . $row['status'] . "</td>
                    <td>" . $created_at . "</td>
                    <td class='actions'>
                        <a href='approve_payment.php?id=" . $row['id'] . "' class='approve'>Approve</a>
                        <a href='reject_payment.php?id=" . $row['id'] . "' class='reject'>Reject</a>
                    </td>
                </tr>";
        }

        echo "</table>";
    } else {
        echo "<p class='no-payments'>No payments found.</p>";
    }

    // Close the connection
    $conn->close();
    ?>

</div>

<!-- Include the admin footer -->
<?php include '../admin/footer.php'; // Adjust the path if necessary ?>

</body>
</html>
