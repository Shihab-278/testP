<?php
// Include database connection
include '../db.php'; // Assuming you have a connection setup in this file

// Fetch pending payments
$stmt = $conn->prepare("SELECT * FROM manual_payments WHERE status = 'pending'");
$stmt->execute();
$payments = $stmt->fetchAll();

include 'header.php'; // Include the header for the page (optional)
?>

<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <!-- Payment table -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Pending Payments</h3>
                        </div>
                        <div class="card-body">
                            <table id="pendingPaymentsTable" class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Transaction ID</th>
                                        <th>User</th>
                                        <th>Amount</th>
                                        <th>Payment Method</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($payments as $payment) { ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($payment['transaction_id']); ?></td>
                                            <td><?php echo htmlspecialchars($payment['user_id']); // You may join the user's name from the users table ?></td>
                                            <td><?php echo htmlspecialchars($payment['amount']); ?></td>
                                            <td><?php echo htmlspecialchars($payment['payment_method']); ?></td>
                                            <td>
                                                <a href="approve_payment.php?id=<?php echo $payment['id']; ?>" class="btn btn-success btn-sm">Approve</a>
                                                <a href="reject_payment.php?id=<?php echo $payment['id']; ?>" class="btn btn-danger btn-sm">Reject</a>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- Include footer (optional) -->
<?php include 'footer.php'; ?>

<!-- Include any required JavaScript -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1.0/dist/js/adminlte.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables@1.10.21/js/jquery.dataTables.min.js"></script>
<script>
    $(document).ready(function() {
        $('#pendingPaymentsTable').DataTable();
    });
</script>
</body>
</html>
