<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

<?php
// admin_user_list.php
session_start();
include('db_connection.php');

// Check if the user is an admin (optional)
if ($_SESSION['role'] != 'admin') {
    header("Location: login.php");
    exit();
}

// Check if the 'id' parameter is set in the URL and is numeric
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $userId = $_GET['id']; // Retrieve the user ID from the URL

    // SQL query to delete the user
    $sql = "DELETE FROM users WHERE id = ?";
    
    // Check if the connection is valid before executing any queries
    if ($conn) {
        // Prepare the query
        if ($stmt = $conn->prepare($sql)) {
            // Bind the 'id' parameter
            $stmt->bind_param("i", $userId);

            // Execute the query
            if ($stmt->execute()) {
                // If deletion is successful, redirect to the user list page with a success message
                $msg = "User deleted successfully";
                header("Location: https://rent.shunlocker.com/admin/user_list.php?msg=" . urlencode($msg)); // URL-encode the message
                exit(); // Ensure no further code runs after header redirection
            } else {
                // Error executing the query
                echo "Error executing query: " . $stmt->error;
            }

            // Close the prepared statement
            $stmt->close();
        } else {
            // Error preparing the statement
            echo "Error preparing statement: " . $conn->error;
        }
    } else {
        echo "Error with database connection.";
    }
} else {
    // If 'id' is not set or is not a valid number
    echo "Invalid user ID.";
}

// Close the database connection
$conn->close();
?>
