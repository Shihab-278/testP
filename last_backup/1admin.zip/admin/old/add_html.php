<form action="save_html.php" method="POST">
    <textarea name="custom_html" rows="10" cols="50" placeholder="Enter your custom HTML here"></textarea>
    <button type="submit">Save HTML</button>
</form>
