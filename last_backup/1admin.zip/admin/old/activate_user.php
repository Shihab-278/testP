<?php
session_start();
include '../db.php';

// Ensure only admin can access this page
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// Retrieve user ID from session
$user_id = $_SESSION['user_id'];

// Get the user ID from the URL
$user_id = $_GET['id'];

// Update the user's status to active (1)
$query = "UPDATE users SET status = 1 WHERE id = $user_id";
if (mysqli_query($conn, $query)) {
    // Redirect back to the users page after successful activation
    header('Location: users.php');
} else {
    echo "Error activating user.";
}
?>
