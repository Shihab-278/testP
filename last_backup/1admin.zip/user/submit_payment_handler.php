<?php
session_start();
include '../db.php';

// Set timezone to Asia/Dhaka (Bangladesh Standard Time)
date_default_timezone_set('Asia/Dhaka');

// Check if the user is logged in and has the correct role
if ($_SESSION['role'] !== 'user') {
    header('Location: ../login.php');
    exit;
}

// Retrieve user ID from session
$user_id = $_SESSION['user_id'];

// Get user information
$stmt = $conn->prepare("SELECT username, `group`, balance FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
$username = $user['username'] ?? '';
$group_name = $user['group'] ?? '';
$balance = $user['balance'] ?? 0;

// Handle the form submission for payment
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $amount = $_POST['amount'];
    $transaction_id = $_POST['transaction_id'];
    $payment_method = $_POST['payment_method'];

    // Insert payment details into the database
    $sql = "INSERT INTO manual_payments (user_id, amount, transaction_id, payment_method, status) 
            VALUES (?, ?, ?, ?, 'pending')";

    $stmt = $conn->prepare($sql);
    if ($stmt->execute([$user_id, $amount, $transaction_id, $payment_method])) {
        $message = "Payment submitted successfully, awaiting approval.";
        $redirect_to = "dashboard.php"; // Adjust this URL if your dashboard is on a different page
    } else {
        $message = "Error: " . $stmt->errorInfo()[2];
        $redirect_to = "dashboard.php"; // Redirect to dashboard even in case of error, or you can change this
    }
}

// Include the header
include 'header.php'; 
?>

<div class="container">
    <h2>Submit Payment</h2>

    <?php if (isset($message)): ?>
        <div class="alert">
            <?php echo htmlspecialchars($message); ?>
        </div>
    <?php endif; ?>

    <!-- Payment Form -->
    <div class="card">
        <form action="" method="POST">
            <div class="form-group">
                <label for="amount">Amount:</label>
                <input type="number" step="0.01" name="amount" required placeholder="Enter payment amount" value="<?= isset($amount) ? htmlspecialchars($amount) : '' ?>">
            </div>

            <div class="form-group">
                <label for="transaction_id">Transaction ID:</label>
                <input type="text" name="transaction_id" required placeholder="Enter transaction ID" value="<?= isset($transaction_id) ? htmlspecialchars($transaction_id) : '' ?>">
            </div>

            <div class="form-group">
                <label for="payment_method">Payment Method:</label>
                <input type="text" name="payment_method" required placeholder="Enter payment method (e.g., Credit Card, PayPal)" value="<?= isset($payment_method) ? htmlspecialchars($payment_method) : '' ?>">
            </div>

            <button type="submit" class="btn btn-primary">Submit Payment</button>
        </form>
    </div>



<?php include 'footer.php'; // Include footer ?>

<?php
// Close the database connection
$conn = null;
?>

<script>
    // If the message is set, we show it and then redirect after 5 seconds
    <?php if (isset($message)): ?>
        setTimeout(function() {
            window.location.href = '<?php echo $redirect_to; ?>';
        }, 5000);  // 5 seconds delay
    <?php endif; ?>
</script>
