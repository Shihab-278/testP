<?php
session_start();
include '../db.php'; // Including PDO database connection
include 'header.php'; // Admin header (you can customize this file for the header)

// Fetch all transactions
$query = "SELECT * FROM transactions";
$stmt = $conn->prepare($query);
$stmt->execute();

$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC); // Fetch all transactions

echo '<div class="transaction-container">';

foreach ($transactions as $index => $row) {
    // Create a styled transaction card
    echo '<div class="transaction-card">';
    
    // Display Transaction Details
    echo '<h3>Transaction ID: ' . $row['transaction_id'] . '</h3>';
    echo '<p><strong>Amount:</strong> ' . number_format($row['amount'], 2) . '</p>';
    echo '<p><strong>Status:</strong> ' . $row['status'] . '</p>';

    // Add Custom Content (e.g., message or advertisement) in the middle
    if ($index == 1) { // You can change the condition to match your logic
        echo '<p><em>Here is some additional content placed in the middle of the list.</em></p>';
    }

    // Fetch user details (e.g., username and email) for the current transaction
    $user_id = $row['user_id']; // Assuming there is a user_id column in the transactions table
    $user_query = "SELECT username, email FROM users WHERE id = :user_id";
    $user_stmt = $conn->prepare($user_query);
    $user_stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $user_stmt->execute();
    $user = $user_stmt->fetch(PDO::FETCH_ASSOC);

    // Display User Info (username and email)
    if ($user) {
        echo '<p><strong>Username:</strong> ' . $user['username'] . '</p>';
        echo '<p><strong>Email:</strong> ' . $user['email'] . '</p>';
    }

    // Buttons to approve or reject
    echo '<div class="transaction-actions">';
    echo "<a class='approve-btn' href='change_status.php?id=" . $row['id'] . "&status=Approved'>Approve</a>";
    echo "<a class='reject-btn' href='change_status.php?id=" . $row['id'] . "&status=Rejected'>Reject</a>";
    echo '</div>'; // End of transaction actions

    echo '</div>'; // End of transaction card
}

echo '</div>'; // End of transaction container

include 'footer.php'; // Footer
?>

