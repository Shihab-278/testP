<?php
session_start();
include '../db.php'; // Including PDO database connection

$query = "SELECT * FROM transactions";
$stmt = $conn->prepare($query);
$stmt->execute();

$transactions = $stmt->fetchAll(PDO::FETCH_ASSOC); // Fetch all transactions

echo '<div class="transaction-container">';
foreach ($transactions as $row) {
    echo '<div class="transaction-card">';
    echo '<h3>Transaction ID: ' . $row['transaction_id'] . '</h3>';
    echo '<p><strong>Amount:</strong> ' . $row['amount'] . '</p>';
    echo '<p><strong>Status:</strong> ' . $row['status'] . '</p>';
    echo '</div>';
}
echo '</div>';
?>
