if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $custom_html = $_POST['custom_html'];

    // Sanitize input
    $custom_html = htmlspecialchars($custom_html, ENT_QUOTES, 'UTF-8');

    // Insert into the database
    $stmt = $pdo->prepare("INSERT INTO custom_html (html_content) VALUES (:html_content)");
    $stmt->execute(['html_content' => $custom_html]);

    echo "HTML saved successfully!";
}
