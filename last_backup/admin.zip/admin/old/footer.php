<footer class="main-footer">
<strong>Developed by <a href="https://domhoster.com" previewlistener="true">Dom Hoster</a></strong>
<div class="float-right d-none d-sm-inline-block">
<b>Version</b> 1.0.2
</div>
</footer>