<?php
session_start();
include '../db.php';

// Set default timezone to Asia/Dhaka (Bangladesh Standard Time)
date_default_timezone_set('Asia/Dhaka');

// Ensure only admin can access this page
if ($_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// Fetch orders
$orders = $conn->query("
    SELECT orders.id, services.service_name, orders.imei, orders.email, orders.status
    FROM orders
    JOIN services ON orders.service_id = services.id
");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $order_id = $_POST['order_id'];
    $status = $_POST['status'];

    $sql = "UPDATE orders SET status='$status' WHERE id='$order_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Order status updated!";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Orders</title>
</head>
<body>
    <h1>Admin: Manage Orders</h1>
    <table border="1">
        <tr>
            <th>Service</th>
            <th>IMEI</th>
            <th>Email</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
        <?php while ($order = $orders->fetch_assoc()): ?>
            <tr>
                <td><?= $order['service_name']; ?></td>
                <td><?= $order['imei']; ?></td>
                <td><?= $order['email']; ?></td>
                <td><?= $order['status']; ?></td>
                <td>
                    <form method="POST">
                        <input type="hidden" name="order_id" value="<?= $order['id']; ?>">
                        <select name="status">
                            <option value="Pending" <?= $order['status'] === 'Pending' ? 'selected' : ''; ?>>Pending</option>
                            <option value="Success" <?= $order['status'] === 'Success' ? 'selected' : ''; ?>>Success</option>
                            <option value="Reject" <?= $order['status'] === 'Reject' ? 'selected' : ''; ?>>Reject</option>
                        </select>
                        <button type="submit">Update</button>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
