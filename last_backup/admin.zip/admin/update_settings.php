<?php
session_start();
include '../db.php';

// Ensure only admin can access this page
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

// Retrieve user ID from session
$user_id = $_SESSION['user_id'];

// Get username from the database
$stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
$username = $user ? $user['username'] : '';

// Database connection (replace with your own credentials)
$pdo = new PDO('mysql:host=localhost;dbname=domhoste_test', 'domhoste_test', 'domhoste_test');

// Fetch current settings from the database
$query = "SELECT * FROM settings WHERE name IN ('recaptcha_enabled', 'recaptcha_site_key', 'recaptcha_secret_key', 'telegram_bot_token', 'telegram_chat_id', 'website_title', 'header_content', 'footer_content', 'custom_html')";
$stmt = $pdo->query($query);
$settings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Set the current values for the settings
$botToken = '';
$chatId = '';
$recaptchaEnabled = 0;
$recaptchaSiteKey = '';
$recaptchaSecretKey = '';
$siteTitle = '';
$headerText = '';
$footerText = '';
$customHtml = '';

foreach ($settings as $setting) {
    if ($setting['name'] == 'telegram_bot_token') {
        $botToken = $setting['value'];
    } elseif ($setting['name'] == 'telegram_chat_id') {
        $chatId = $setting['value'];
    } elseif ($setting['name'] == 'recaptcha_enabled') {
        $recaptchaEnabled = (int)$setting['value'];
    } elseif ($setting['name'] == 'recaptcha_site_key') {
        $recaptchaSiteKey = $setting['value'];
    } elseif ($setting['name'] == 'recaptcha_secret_key') {
        $recaptchaSecretKey = $setting['value'];
    } elseif ($setting['name'] == 'website_title') {
        $siteTitle = $setting['value'];
    } elseif ($setting['name'] == 'header_content') {
        $headerText = $setting['value'];
    } elseif ($setting['name'] == 'footer_content') {
        $footerText = $setting['value'];
    } elseif ($setting['name'] == 'custom_html') {
        $customHtml = $setting['value'];
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $botToken = $_POST['telegram_bot_token'];
    $chatId = $_POST['telegram_chat_id'];
    $recaptchaEnabled = isset($_POST['recaptcha_enabled']) ? 1 : 0;
    $recaptchaSiteKey = $_POST['recaptcha_site_key'];
    $recaptchaSecretKey = $_POST['recaptcha_secret_key'];
    $siteTitle = $_POST['website_title'];
    $headerText = $_POST['header_content'];
    $footerText = $_POST['footer_content'];
    $customHtml = $_POST['custom_html'];

    // Save the updated settings in the database
    $stmt = $pdo->prepare("INSERT INTO settings (name, value) VALUES (?, ?) ON DUPLICATE KEY UPDATE value = ?");
    $stmt->execute(['telegram_bot_token', $botToken, $botToken]);
    $stmt->execute(['telegram_chat_id', $chatId, $chatId]);
    $stmt->execute(['recaptcha_enabled', $recaptchaEnabled, $recaptchaEnabled]);
    $stmt->execute(['recaptcha_site_key', $recaptchaSiteKey, $recaptchaSiteKey]);
    $stmt->execute(['recaptcha_secret_key', $recaptchaSecretKey, $recaptchaSecretKey]);
    $stmt->execute(['website_title', $siteTitle, $siteTitle]);
    $stmt->execute(['header_content', $headerText, $headerText]);
    $stmt->execute(['footer_content', $footerText, $footerText]);
    $stmt->execute(['custom_html', $customHtml, $customHtml]);

    $successMessage = 'Settings updated successfully.';
}
?>

<?php include 'header.php'; // Include your header ?>

<!-- Updated Form Code -->
<div class="container">
    <h2>Update Settings</h2>

    <?php if (isset($successMessage)): ?>
        <div class="alert success"><?php echo htmlspecialchars($successMessage); ?></div>
    <?php endif; ?>

    <form method="post" action="update_settings.php" id="settings-form">
        <!-- Website General Settings -->
        <div class="form-section">
            <h3>Website General Settings</h3>
            <div class="form-group">
                <label for="website_title">Website Title:</label>
                <input type="text" id="website_title" name="website_title" value="<?php echo htmlspecialchars($siteTitle); ?>" required>
            </div>

            <div class="form-group">
                <label for="header_content">Header Text:</label>
                <input type="text" id="header_content" name="header_content" value="<?php echo htmlspecialchars($headerText); ?>" required>
            </div>

            <div class="form-group">
                <label for="footer_content">Footer Text:</label>
                <input type="text" id="footer_content" name="footer_content" value="<?php echo htmlspecialchars($footerText); ?>" required>
            </div>
        </div>

        <!-- Telegram Settings Section -->
        <div class="form-section">
            <h3>Telegram Settings</h3>
            <div class="form-group">
                <label for="telegram_bot_token">Telegram Bot Token:</label>
                <input type="text" id="telegram_bot_token" name="telegram_bot_token" value="<?php echo htmlspecialchars($botToken); ?>" required>
            </div>

            <div class="form-group">
                <label for="telegram_chat_id">Telegram Chat ID:</label>
                <input type="text" id="telegram_chat_id" name="telegram_chat_id" value="<?php echo htmlspecialchars($chatId); ?>" required>
            </div>
        </div>

        <!-- reCAPTCHA Settings Section -->
        <div class="form-section">
            <h3>reCAPTCHA Settings</h3>
            <div class="form-group">
                <label for="recaptcha_enabled">Enable reCAPTCHA:</label>
                <input type="checkbox" id="recaptcha_enabled" name="recaptcha_enabled" <?php echo $recaptchaEnabled ? 'checked' : ''; ?> onchange="toggleRecaptchaFields()">
            </div>

            <div class="form-group">
                <label for="recaptcha_site_key">reCAPTCHA Site Key:</label>
                <input type="text" id="recaptcha_site_key" name="recaptcha_site_key" value="<?php echo htmlspecialchars($recaptchaSiteKey); ?>" <?php echo !$recaptchaEnabled ? 'disabled' : ''; ?>>
            </div>

            <div class="form-group">
                <label for="recaptcha_secret_key">reCAPTCHA Secret Key:</label>
                <input type="text" id="recaptcha_secret_key" name="recaptcha_secret_key" value="<?php echo htmlspecialchars($recaptchaSecretKey); ?>" <?php echo !$recaptchaEnabled ? 'disabled' : ''; ?>>
            </div>
        </div>

        <!-- Custom HTML Settings Section -->
        <div class="form-section">
            <h3>Custom HTML</h3>
            <div class="form-group">
                <label for="custom_html">Custom HTML (e.g., for header or footer):</label>
                <textarea id="custom_html" name="custom_html" rows="6" required><?php echo htmlspecialchars($customHtml); ?></textarea>
            </div>
        </div>

        <!-- Submit Button -->
        <div style="text-align: center;">
            <button type="submit" class="submit-btn">Save Settings</button>
        </div>
    </form>
</div>

<!-- JavaScript for reCAPTCHA Enable/Disable -->
<script>
    function toggleRecaptchaFields() {
        const isChecked = document.getElementById('recaptcha_enabled').checked;
        document.getElementById('recaptcha_site_key').disabled = !isChecked;
        document.getElementById('recaptcha_secret_key').disabled = !isChecked;
    }

    // Initialize reCAPTCHA fields based on checkbox state
    toggleRecaptchaFields();
</script>

<?php include 'footer.php'; // Include your footer ?>

<!-- CSS for Light Mode Styling -->
<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f9f9f9;
        color: #333;
        margin: 0;
        padding: 0;
    }

    .container {
        max-width: 800px;
        margin: 40px auto;
        background-color: #ffffff;
        padding: 25px 30px;
        border-radius: 10px;
        box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
   
.2);
}

h2 {
    text-align: center;
    color: #ffffff;
    font-size: 28px;
    font-weight: bold;
    margin-bottom: 20px;
}

h3 {
    font-size: 20px;
    color: #1f2d3d;
    border-bottom: 1px solid #444;
    padding-bottom: 8px;
    margin-bottom: 15px;
}

.form-section {
    margin-bottom: 30px;
}

.form-group {
    margin-bottom: 20px;
}

label {
    display: block;
    font-size: 14px;
    color: #1f2d3d;
    font-weight: 500;
    margin-bottom: 8px;
}

input[type="text"],
textarea,
input[type="password"] {
    width: 100%;
    padding: 12px 15px;
    font-size: 15px;
    background-color: #353545;
    border: 1px solid #444;
    border-radius: 8px;
    color: #e4e4f0;
    transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

input[type="text"]:focus,
textarea:focus,
input[type="password"]:focus {
    border-color: #62e4a6;
    box-shadow: 0 0 5px #62e4a6;
    outline: none;
}

textarea {
    min-height: 120px;
    resize: vertical;
}

input[type="checkbox"] {
    margin-right: 10px;
    transform: scale(1.2);
}

button.submit-btn {
    width: 100%;
    padding: 12px 20px;
    font-size: 16px;
    font-weight: bold;
    text-transform: uppercase;
    background-color: #62e4a6;
    color: #1e1e2f;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

button.submit-btn:hover {
    background-color: #4ec98c;
}

.alert {
    background-color: #28a745;
    color: #fff;
    padding: 15px;
    margin-bottom: 20px;
    border-radius: 5px;
    text-align: center;
}

.alert.success {
    background-color: #1e9453;
}

/* Responsive Design */
@media screen and (max-width: 768px) {
    .container {
        padding: 20px;
    }

    h2 {
        font-size: 24px;
    }

    h3 {
        font-size: 18px;
    }

    button.submit-btn {
        font-size: 14px;
    }
}
