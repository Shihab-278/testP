<?php
include '../db.php';  // Include database connection file

// Query to fetch pending payments
$query = "SELECT * FROM payments WHERE payment_status = 'pending'";

// Execute the query
$result = mysqli_query($conn, $query);

// Check if the query execution was successful
if (!$result) {
    // If the query fails, print the error and the query
    echo "Error executing query: " . mysqli_error($conn);
    echo "<br>SQL Query: " . $query; // Display the query being executed for debugging purposes
} else {
    // Check if there are any rows returned
    if (mysqli_num_rows($result) > 0) {
        // If results are found, fetch and display the data
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<p>Payment ID: " . $row['payment_id'] . " | Amount: " . $row['amount'] . " | Method: " . $row['payment_method'] . " | Transaction ID: " . $row['transaction_id'] . "</p>";
            echo "<a href='confirm_payment.php?id=" . $row['payment_id'] . "'>Confirm Payment</a><br>";
        }
    } else {
        echo "No pending payments found.";
    }
}
?>
