<?php
session_start();
include '../db.php'; // Include the database connection file

// Check if the approval request is made
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['approve_id'])) {
    $user_id = $_GET['approve_id'];

    // Prepare and execute the SQL query using a prepared statement to prevent SQL injection
    $stmt = $conn->prepare("UPDATE users SET banned = 0 WHERE id = ?");
    $stmt->bind_param("i", $user_id);

    if ($stmt->execute()) {
        // Redirect back to the list of pending users after successful activation
        header("Location: admin_approval.php?success=1");
        exit();
    } else {
        // Display error message if the query fails
        echo "Error: " . $stmt->error;
    }

    $stmt->close(); // Close the prepared statement
}

// Fetch the users who are pending approval (banned = 1)
$sql = "SELECT * FROM users WHERE banned = 1";
$result = mysqli_query($conn, $sql);

echo "<h3>Pending Approvals</h3>";

// Display the list of users who need approval
if (mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        echo "ID: " . $row['id'] . " | Username: " . $row['username'] . " | 
              <a href='?approve_id=" . $row['id'] . "'>Approve</a><br>";
    }
} else {
    echo "No pending users for approval.";
}

?>

<?php
// Display success message if user account was approved
if (isset($_GET['success']) && $_GET['success'] == 1) {
    echo "<div class='alert alert-success'>User account has been activated successfully!</div>";
}
?>

