<form action="submit_transaction.php" method="POST">
    <label for="amount">Amount:</label>
    <input type="text" name="amount" required><br>
    
    <label for="transaction_id">Transaction ID:</label>
    <input type="text" name="transaction_id" required><br>
    
    <label for="username">Username:</label>
    <input type="text" name="username" required><br>
    
    <input type="submit" value="Submit">
</form>
