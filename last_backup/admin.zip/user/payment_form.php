<?php
session_start();
include '../db.php'; // Include the database connection file


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $transaction_id = $_POST['transaction_id'];
    $amount = $_POST['amount'];
    $payment_method = $_POST['payment_method'];

    // Insert payment details into the database
    $query = "INSERT INTO manual_payments (user_id, transaction_id, amount, payment_method) 
              VALUES ('$user_id', '$transaction_id', '$amount', '$payment_method')";
    
    if (mysqli_query($conn, $query)) {
        echo "পেমেন্ট সফলভাবে সাবমিট করা হয়েছে।";
    } else {
        echo "ত্রুটি ঘটেছে!";
    }
}
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ম্যানুয়াল পেমেন্ট ফর্ম</title>
</head>
<body>
    <h1>ম্যানুয়াল পেমেন্ট সাবমিট করুন</h1>
    <form action="payment_form.php" method="POST">
        <label for="user_id">ব্যবহারকারীর আইডি:</label><br>
        <input type="text" name="user_id" required><br><br>

        <label for="transaction_id">ট্রানজেকশন আইডি:</label><br>
        <input type="text" name="transaction_id" required><br><br>

        <label for="amount">পরিমাণ:</label><br>
        <input type="text" name="amount" required><br><br>

        <label for="payment_method">পেমেন্ট পদ্ধতি:</label><br>
        <input type="text" name="payment_method" required><br><br>

        <input type="submit" value="পেমেন্ট সাবমিট করুন">
    </form>
</body>
</html>
