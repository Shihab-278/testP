<?php
session_start();
include '../db.php'; // Including PDO database connection

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Debugging: Print the POST data to check if all fields are sent
    var_dump($_POST);  // Remove this line after debugging

    // Check if all the required fields are set
    if (isset($_POST['amount'], $_POST['transaction_id'], $_POST['username'])) {
        // Get the POST data
        $amount = $_POST['amount'];
        $transaction_id = $_POST['transaction_id'];
        $username = $_POST['username']; // Get the username from the form

        // Check if the values are set and not empty
        if (empty($amount) || empty($transaction_id) || empty($username)) {
            echo "Error: All fields are required.";
            exit;
        }

        // Prepare the SQL statement with placeholders
        $query = "INSERT INTO transactions (amount, transaction_id, status, username) VALUES (:amount, :transaction_id, :status, :username)";
        $stmt = $conn->prepare($query);

        // Bind parameters to prevent SQL injection
        $status = 'Pending'; // Default status
        $stmt->bindParam(':amount', $amount);
        $stmt->bindParam(':transaction_id', $transaction_id);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':username', $username); // Bind username parameter

        // Execute the query and check for success
        if ($stmt->execute()) {
            echo "Transaction submitted successfully!";
        } else {
            // Capture the error message if query fails
            $errorInfo = $stmt->errorInfo();
            echo "Error: Unable to submit transaction. Error message: " . $errorInfo[2];
        }
    } else {
        echo "Error: Required form data is missing.";
    }
}
?>
