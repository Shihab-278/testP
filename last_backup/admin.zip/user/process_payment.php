<?php
session_start();
include '../db.php'; // Include the database connection file

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the POST data
    $amount = $_POST['amount'];
    $payment_method = $_POST['payment_method'];
    $transaction_id = $_POST['transaction_id'];
    $user_id = 1; // Example user ID (you can fetch it based on the session or login)

    // Debugging: Check the input values before proceeding
    echo "User ID: " . $user_id . "<br>";
    echo "Amount: " . $amount . "<br>";
    echo "Payment Method: " . $payment_method . "<br>";
    echo "Transaction ID: " . $transaction_id . "<br>";

    // Ensure amount is numeric and cast to float
    if (!is_numeric($amount)) {
        echo "Invalid amount. Please enter a valid number.<br>";
        exit;
    }
    $amount = (float) $amount;  // Ensure it's treated as a float

    // Ensure payment_method and transaction_id are strings
    $payment_method = mysqli_real_escape_string($conn, $payment_method);
    $transaction_id = mysqli_real_escape_string($conn, $transaction_id);

    // Debugging: Ensure that values are now correct
    echo "Amount (float): " . $amount . "<br>";
    echo "Payment Method (string): " . $payment_method . "<br>";
    echo "Transaction ID (string): " . $transaction_id . "<br>";

    // Check if the database connection is working
    if (mysqli_connect_errno()) {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit;
    } else {
        echo "Database connection established successfully.<br>";
    }

    // SQL query to insert payment details directly
    $query = "INSERT INTO payments (user_id, amount, payment_method, transaction_id) 
              VALUES ($user_id, $amount, '$payment_method', '$transaction_id')";

    // Execute the query
    if (mysqli_query($conn, $query)) {
        echo "Payment successfully submitted!<br>";
    } else {
        echo "Error executing query: " . mysqli_error($conn) . "<br>";
    }
}
?>
