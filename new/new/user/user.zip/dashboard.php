<?php
session_start();
include '../db.php';

// Set timezone to Asia/Kolkata (Indian Standard Time)
date_default_timezone_set('Asia/Kolkata');
// Check if the user is logged in and has the correct role
if ($_SESSION['role'] !== 'user') {
    header('Location: ../login.php');
    exit;
}

// Retrieve user ID from session
$user_id = $_SESSION['user_id'];

// Get username from the database
$stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
$username = $user ? $user['username'] : '';

// Get user information from the database
$stmt = $conn->prepare("SELECT username, `group` FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
$username = $user ? $user['username'] : '';
$group_name = $user ? $user['group'] : '';

// Get user info
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch();

// Fetch user's generated tools
$tools_stmt = $conn->prepare("SELECT tools.tool_name, tools.tool_username, tools.tool_password, user_tools.generated_at 
                              FROM user_tools 
                              JOIN tools ON user_tools.tool_id = tools.id 
                              WHERE user_tools.user_id = ?");
$tools_stmt->execute([$_SESSION['user_id']]);
$generated_tools = $tools_stmt->fetchAll();

// Fetch today's credit used from the credit_usage table
$today = date('Y-m-d');  // Get today's date
$credit_stmt = $conn->prepare("SELECT COALESCE(SUM(credits_used), 0) AS total_used 
                               FROM credit_usage 
                               WHERE user_id_fk = ? AND DATE(usage_date) = ?");
$credit_stmt->execute([$_SESSION['user_id'], $today]);
$credit_usage = $credit_stmt->fetch();

$total_today_amount = $credit_usage['total_used'] ?? 0;  // Ensure 0 is displayed if no credits were used

include 'header.php'; // Include user-side header
?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h4><i class="fa fa-caret-right fw-r5"></i> Dashboard</h4>
    </section>
        <!-- Breadcrumb Navigation -->
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">User Dashboard</li>
            </ol>
        </nav>

    <section class="content">
    <div class="container-fluid">
        <div class="row">
            <!-- Small Box: Your Balance -->
            <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                <div class="small-box bg-danger">
                    <div class="inner">
                        <h3><?php echo htmlspecialchars($user['balance']); ?></h3>
                        <p>Credits in Account</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-credit-card"></i>
                    </div>
                </div>
            </div>
            <!-- Small Box: Total Generated Tools -->
            <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                <div class="small-box bg-info">
                    <div class="inner">
                        <h3><?php echo count($generated_tools); ?></h3>
                        <p>Generated Tools</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-tools"></i>
                    </div>
                </div>
            </div>
            <!-- Small Box: Today's Credit Used -->
            <div class="col-12 col-sm-6 col-md-4 col-lg-3">
                <div class="small-box bg-success">
                    <div class="inner">
                        <h3><?php echo htmlspecialchars($total_today_amount); ?></h3>
                        <p>Today's Credits Usage</p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-calendar-day"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



</div>

<?php include 'footer.php'; ?>
