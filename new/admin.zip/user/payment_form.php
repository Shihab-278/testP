<form action="submit_payment.php" method="POST">
    <label for="transaction_id">Transaction ID:</label>
    <input type="text" id="transaction_id" name="transaction_id" required>
    
    <label for="amount">Amount:</label>
    <input type="number" id="amount" name="amount" step="0.01" required>
    
    <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id']; ?>">
    <button type="submit">Submit</button>
</form>
