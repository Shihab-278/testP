
<footer class="main-footer">
<strong>Developed by <a href="https://domhoster.com" previewlistener="true">Dom Hoster</a></strong>
<div class="float-right d-none d-sm-inline-block">
<b>Version</b> 1.0.1
</div>
</footer>

<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<!-- /.control-sidebar -->

</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- Bootstrap 4 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- AdminLTE -->
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1.0/dist/js/adminlte.min.js"></script>

<script>
function togglePasswordVisibility() {
    const passwordInput = document.getElementById('toolPassword');
    const toggleCheckbox = document.getElementById('togglePassword');
    passwordInput.type = toggleCheckbox.checked ? 'text' : 'password';
}
</script>



</body>
</html>
