<?php 
phpinfo(); 

echo "The time is " . date('Y/m/d') . " " . date("h:i:sa");

?>
