<marquee id="news" style="color: #ff5733; display: flex; font-size: 22px; font-weight: 800; justify-content: center; width: 90%; margin: auto;" behavior="scroll" direction="left" onmouseover="this.stop();" onmouseout="this.start();"> ⚡ TECNO/INFINIX MDM ⚡ SAMSUNG FRP ⚡ Honor FRP KEY ⚡ Xiaomi FRP/FLASH/MI ACCOUNT ⚡ Realme Flash On ⚡ Oneplus Flash On ⚡ Nokia Reset+FRP On ⚡ Sam FRP On ⚡ </marquee>
<html lang="en"><head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GSMXTOOL Tool Server</title>
    <meta name="description" content="">
    <meta name="keywords" content="tool rental, activation services, GSMXTOOL, unlock tool, AMT tool, TFM tool, SRS tool">
    <meta name="author" content="GSMXTOOL">
    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <!-- Bootstrap 4 CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Navbar (Header) -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
        <a href="/" class="navbar-brand active">
            <img src="https://rent.shunlocker.com/user/img/logo.png" alt="logo" class="brand-image elevation-3" style="height: 40px;">
            <span class="brand-text font-weight-light">GSMXTOOL</span>
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link text-white" href="https://rent.shunlocker.com/user/dashboard.php"><i class="fas fa-home"></i>My Account</a>
                </li>
        </div>
    </div>
</nav>
           <h1 class="text-center mb-4">Welcome to GSMXTOOL</h1>
            <h1 class="text-center mb-4">24Hour Ready Tool </h1>
            <p class="text-center mb-5">Your one-stop solution for all kinds of tool rental and activation.</p>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Click to Show Text</title>
    <!-- Add Font Awesome CDN for the icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Styling the body to center everything */
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f0f0f0; /* Light background for the page */
            font-family: 'Arial', sans-serif;
            flex-direction: column;
        }

        /* Styling the box container to create a row of boxes */
        .boxes-container {
            display: flex;
            justify-content: space-around; /* Space between the boxes */
            width: 80%; /* Container width */
            max-width: 1200px; /* Maximum width of the container */
        }

        .box-container {
            display: flex;
            flex-direction: column; /* Aligning image on top and text below */
            align-items: center;
            border: 2px solid #3498db; /* Blue border for the box */
            padding: 20px;
            width: 250px;
            height: 350px;
            border-radius: 15px; /* Rounded corners */
            background-color: #fff; /* White background inside the box */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Soft shadow for the box */
            transition: all 0.3s ease; /* Smooth transition on hover */
            position: relative; /* Positioning for text outside the box */
        }

        .box-container:hover {
            transform: scale(1.05); /* Slight zoom effect on hover */
        }

        .box-container img {
            max-width: 150px; /* Image size */
            height: auto;
            margin-bottom: 15px; /* Space between image and text */
            border-radius: 8px; /* Rounded corners for the image */
            cursor: pointer;
        }

        /* Styling for the "Payment Method" text outside the box */
        .payment-method-text {
            position: absolute;
            top: -20px; /* Move text above the box */
            left: 50%;
            transform: translateX(-50%); /* Center the text horizontally */
            font-size: 18px;
            font-weight: bold;
            color: #2c3e50; /* Dark color for text */
            background-color: #fff;
            padding: 0 10px; /* Padding around the text */
            border-radius: 10px;
            border: 2px solid #3498db; /* Blue border around text */
        }

        .box-content {
            display: none; /* Hide the content by default */
            font-size: 14px;
            color: #7f8c8d; /* Lighter text color for the paragraph */
            line-height: 1.5;
            text-align: center;
            margin-top: 15px;
        }

        .social-icons {
            display: flex;
            justify-content: center;
            gap: 15px; /* Space between the icons */
            margin-top: 15px;
        }

        .social-icons i {
            font-size: 30px; /* Icon size */
            color: #3498db; /* Color of the icons */
            cursor: pointer;
            transition: transform 0.3s ease;
        }

        .social-icons i:hover {
            transform: scale(1.2); /* Zoom effect on hover */
        }
    </style>
</head>
<body>

    <div class="boxes-container">
        <!-- First Box -->
        <div class="box-container">
            <div class="payment-method-text">Bkash</div>
            <img src="https://rent.shunlocker.com/user/img/logo.png" alt="Payment Image 1" onclick="toggleText(1)">
            <p>Bkash Personal.</p>
              <style>
    .bold-text {
        font-weight: bold;
    }
</style>

<p class="bold-text">01908021829</p>
            <div class="box-content" id="text-1">
                <p>This box represents the first payment method. You can use various methods to pay.</p>
            </div>
            <div class="social-icons">
                <!-- WhatsApp Icon -->
                <a href="https://wa.me" target="_blank">
                    <i class="fab fa-whatsapp"></i>
                </a>
                <!-- Telegram Icon -->
                <a href="https://t.me" target="_blank">
                    <i class="fab fa-telegram"></i>
                </a>
            </div>
        </div>

        <!-- Second Box -->
        <div class="box-container">
            <div class="payment-method-text">Nagad</div>
            <img src="https://rent.shunlocker.com/user/img/logo.png" alt="Payment Image 2" onclick="toggleText(2)">
             <p>Bkash Personal.</p>
              <style>
    .bold-text {
        font-weight: bold;
    }
</style>

<p class="bold-text">01908021829</p>

            <div class="box-content" id="text-2">
                <p>This is the second payment method. Various digital options are available.</p>
            </div>
            <div class="social-icons">
                <!-- WhatsApp Icon -->
                <a href="https://wa.me" target="_blank">
                    <i class="fab fa-whatsapp"></i>
                </a>
                <!-- Telegram Icon -->
                <a href="https://t.me" target="_blank">
                    <i class="fab fa-telegram"></i>
                </a>
            </div>
        </div>

        <!-- Third Box -->
        <div class="box-container">
            <div class="payment-method-text">Upay</div>
            <img src="https://rent.shunlocker.com/user/img/logo.png" alt="Payment Image 3" onclick="toggleText(3)">
            <p>Bkash Personal.</p>
              <style>
    .bold-text {
        font-weight: bold;
    }
</style>

<p class="bold-text">01908021829</p>
            <div class="box-content" id="text-3">
                <p>This is the third payment method. You can use different options like credit cards or wallets.</p>
            </div>
            <div class="social-icons">
                <!-- WhatsApp Icon -->
                <a href="https://wa.me" target="_blank">
                    <i class="fab fa-whatsapp"></i>
                </a>
                <!-- Telegram Icon -->
                <a href="https://t.me" target="_blank">
                    <i class="fab fa-telegram"></i>
                </a>
            </div>
        </div>

        <!-- Fourth Box -->
        <div class="box-container">
            <div class="payment-method-text">Binance</div>
            <img src="https://rent.shunlocker.com/user/img/logo.png" alt="Payment Image 4" onclick="toggleText(4)">
            <p>Bkash Personal</p>
              <style>
    .bold-text {
        font-weight: bold;
    }
</style>

<p class="bold-text">01908021829</p>
            <div class="box-content" id="text-4">
                <p>This is the fourth payment method. You can use multiple online payment platforms.</p>
            </div>
            <div class="social-icons">
                <!-- WhatsApp Icon -->
                <a href="https://wa.me" target="_blank">
                    <i class="fab fa-whatsapp"></i>
                </a>
                <!-- Telegram Icon -->
                <a href="https://t.me" target="_blank">
                    <i class="fab fa-telegram"></i>
                </a>
            </div>
        </div>
    </div>

    <script>
        // Function to toggle the text visibility when an image is clicked
        function toggleText(boxNumber) {
            var textElement = document.getElementById("text-" + boxNumber);
            // Toggle visibility of the corresponding text box
            if (textElement.style.display === "none" || textElement.style.display === "") {
                textElement.style.display = "block";
            } else {
                textElement.style.display = "none";
            }
        }
    </script>
<!-- Footer -->
    <footer class="bg-dark text-white text-center py-3 mt-5">
        <div class="container">
            <p>&copy; 2024 GSMXTOOL. All rights reserved.</p>
            <p>Follow us on: 
                <a href="https://www.facebook.com/gsmxtool" target="_blank" class="text-white ml-2"><i class="fab fa-facebook"></i></a>
                <a href="https://twitter.com/gsmxtool" target="_blank" class="text-white ml-2"><i class="fab fa-twitter"></i></a>
                <a href="https://www.instagram.com/gsmxtool" target="_blank" class="text-white ml-2"><i class="fab fa-instagram"></i></a>
            </p>
        </div>
    </footer>

    <!-- Bootstrap and jQuery Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</body>
</html>
